<?php
$dirToDel = 'apps/'.$_GET['a'];
array_map('unlink', glob("$dirToDel/*.*"));
rmdir($dirToDel);
header("Location: index.php");
die();
?>