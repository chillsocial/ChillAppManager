<?php 
if(!file_exists('user.txt')){
	header("Location: setuser.php");
	die();
}else{
	$u = file_get_contents('user.txt');
	$new_str = str_replace(' ', '', 'C:\Users\ '.$u.'\Desktop\Webapp-win32-x64\resources\app\nativefier.json');
	$noEmptySpaces = trim(preg_replace('/\s\s+/', '', file_get_contents("https://raw.githubusercontent.com/chillsocial/ChillAppManager/main/latestUserAgent.txt")));
	file_put_contents($new_str ,'{"accessibilityPrompt":true,"alwaysOnTop":false,"arch":"x64","asar":false,"blockExternalUrls":false,"bounce":false,"buildDate":'.time().',"clearCache":false,"counter":false,"darwinDarkModeSupport":false,"disableContextMenu":false,"disableDevTools":false,"disableGpu":false,"disableOldBuildWarning":true,"electronVersionUsed":"16.0.8","enableEs3Apis":false,"fastQuit":false,"fullScreen":false,"height":800,"hideWindowFrame":false,"ignoreCertificate":false,"ignoreGpuBlacklist":false,"insecure":false,"isUpgrade":false,"maximize":false,"name":"Webapp","nativefierVersion":"46.1.0","portable":false,"quiet":false,"showMenuBar":true,"singleInstance":false,"strictInternalUrls":false,"targetUrl":"http://localhost","tray":"false","userAgent":"'.$noEmptySpaces.'","userAgentHonest":false,"width":1280,"widevine":false,"win32metadata":{},"zoom":1,"oldBuildWarningText":"","internalUrls": "(.*)"}');
	echo '<title>Chill App Manager | '.$_GET['a'].'</title>
<head>
<style>
body {
  background-color: black;
  color: white;
  font-family: Arial, Helvetica, sans-serif;
}

a:link {
  color: white;
}

a:visited {
  color: white;
}

a:hover {
  color: white;
}

a:active {
  color: white;
}
</style>
</head>
<body>
<center>';
$appCont = file_get_contents('apps/'.$_GET['a'].'/preload.txt');
$appJson = json_decode($appCont);
echo '<audio loop autoplay>
    <source src="'.$appJson->preMusicTrack.'" type="audio/'.$appJson->preMusicType.'">
</audio>
';
echo '<img src="'.$appJson->preBanner.'" alt="'.$appJson->preAltTxt.'" width="100%" height="90%">';
echo '<h2><a href="'.'apps/'.$_GET['a'].'/'.$appJson->startFile.'">Start App</a> | <a href="unins.php?a='.$_GET['a'].'">Uninstall App</a> | <a href="index.php">Main Menu</a></h2>';
}
?>
</center>
</body>