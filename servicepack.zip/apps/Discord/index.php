<?php
header("Location: https://discord.com/app");
die();
?>
