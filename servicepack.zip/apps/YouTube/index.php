<?php
header("Location: https://www.youtube.com/tv");
die();
?>
