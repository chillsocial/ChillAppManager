<title>Chill App Store</title>
<head>
<style>
body {
  background-color: black;
  color: white;
  font-family: Arial, Helvetica, sans-serif;
}

a:link {
  color: white;
}

a:visited {
  color: white;
}

a:hover {
  color: white;
}

a:active {
  color: white;
}
</style>
</head>
<body>
<center>
<audio loop autoplay>
    <source src="https://vgmsite.com/soundtracks/wii-shop-channel-wii/hqewrabe/02_Shop%20Channel.mp3" type="audio/mp3">
</audio>
<h2><a href="http://localhost">Return to Chill Menu</a></h2>
<iframe src="http://localhost/apps/Store/menu.php" style="border:0px #ffffff none;" name="store" scrolling="yes" frameborder="1" marginheight="0px" marginwidth="0px" height="90%" width="100%" allowfullscreen></iframe>
</center>