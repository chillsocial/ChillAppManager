<?php 
if(!file_exists('user.txt')){
	header("Location: setuser.php");
	die();
}else{
	$u = file_get_contents('user.txt');
	$new_str = str_replace(' ', '', 'C:\Users\ '.$u.'\Desktop\Webapp-win32-x64\resources\app\nativefier.json');
	$noEmptySpaces = trim(preg_replace('/\s\s+/', '', file_get_contents("https://raw.githubusercontent.com/chillsocial/ChillAppManager/main/latestUserAgent.txt")));
	file_put_contents($new_str ,'{"accessibilityPrompt":true,"alwaysOnTop":false,"arch":"x64","asar":false,"blockExternalUrls":false,"bounce":false,"buildDate":'.time().',"clearCache":false,"counter":false,"darwinDarkModeSupport":false,"disableContextMenu":false,"disableDevTools":false,"disableGpu":false,"disableOldBuildWarning":true,"electronVersionUsed":"16.0.8","enableEs3Apis":false,"fastQuit":false,"fullScreen":false,"height":800,"hideWindowFrame":false,"ignoreCertificate":false,"ignoreGpuBlacklist":false,"insecure":false,"isUpgrade":false,"maximize":false,"name":"Webapp","nativefierVersion":"46.1.0","portable":false,"quiet":false,"showMenuBar":true,"singleInstance":false,"strictInternalUrls":false,"targetUrl":"http://localhost","tray":"false","userAgent":"'.$noEmptySpaces.'","userAgentHonest":false,"width":1280,"widevine":false,"win32metadata":{},"zoom":1,"oldBuildWarningText":"","internalUrls": "(.*)"}');
	echo '<title>Chill App Manager | Main Menu</title>
<head>
<style>
body {
  background-color: black;
  color: white;
  font-family: Arial, Helvetica, sans-serif;
}

a:link {
  color: white;
}

a:visited {
  color: white;
}

a:hover {
  color: white;
}

a:active {
  color: white;
}
</style>
</head>
<body>
<center>';
	echo '<h1>Chill App Manager</h1><h2>Hello, '.$u.'</h2>';
	echo '<audio loop autoplay>
    <source src="https://vgmsite.com/soundtracks/wii-system-menu/tcrljspa/002%20-%20Menu.mp3" type="audio/mp3">
</audio>';
	$files = scandir('apps/');
$dir = new DirectoryIterator('apps/');
foreach ($dir as $fileinfo) {
    if ($fileinfo->isDir() && !$fileinfo->isDot()) {
		$folderName = $fileinfo->getFilename();
        $appName = $fileinfo->getFilename();
		$appJson = file_get_contents('apps/'.$appName.'/preload.txt');
		$appDecode = json_decode($appJson);
		echo '<a href="preload.php?a='.$appName.'"><img src="'.$appDecode->preIcon.'" alt="'.$appDecode->preAltTxt.'" width="100" height="100"></a>';
    }
}
}
?>
<p>(C)2022-<?php
echo date("Y");
?> @chillsocial on Github, all rights reserved.</p>
</center>
</body>