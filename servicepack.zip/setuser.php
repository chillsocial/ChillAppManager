<title>Chill App Manager | Configure Username</title>
<head>
<style>
body {
  background-color: black;
  color: white;
  font-family: Arial, Helvetica, sans-serif;
}

a:link {
  color: white;
}

a:visited {
  color: white;
}

a:hover {
  color: white;
}

a:active {
  color: white;
}
</style>
</head>
<body>
<center>
<?php
if(isset($_POST['u'])){
	file_put_contents("user.txt",$_POST['u']);
	header("Location: index.php");
	die();
}else{
	echo '<h1>One last step!</h1><p>You need to enter your computers username. This is nessecary for service updates to the frontend Nativefier app. To find this, press the Windows key, search for <b>cmd</b>, click it and run command <b>echo %USERNAME%</b>. The response to that is your computers username. This will not be shared externally.</p>';
	echo '<p><b>If this is your first time using Chill App Manager, after doing this please restart the app.</b> Some features may be unavalible or not work as intended until you restart it.</p>';
	echo '<form action="setuser.php" method="post">
Username: <input type="text" name="u" id="u" required><input type="submit" value="Complete Configuration">
</form>';
}
?>
